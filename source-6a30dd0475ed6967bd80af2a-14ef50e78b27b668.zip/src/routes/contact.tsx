import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
    .join('&')
}

function ContactForm() {
  const [fields, setFields] = useState({ name: '', email: '', phone: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await fetch('/contact-form.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({ 'form-name': 'contact', ...fields }),
      })
      setSubmitted(true)
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="text-center py-16">
        <div className="text-6xl mb-4">🙏</div>
        <h3 className="text-2xl font-bold mb-3" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
          Pranam! Your message has been received.
        </h3>
        <p className="text-base" style={{ color: '#5C3D11' }}>
          Thank you for reaching out to Beteswar Shiva Mandir. Our team will respond within 24–48 hours. May Lord Shiva bless you abundantly.
        </p>
        <div className="mt-6" style={{ color: '#D4A017', fontSize: '2rem', letterSpacing: '0.5rem' }}>ॐ नमः शिवाय</div>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <input type="hidden" name="form-name" value="contact" />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm font-semibold mb-1" style={{ color: '#5C3D11', fontFamily: 'Georgia, serif' }}>
            Full Name *
          </label>
          <input
            type="text"
            name="name"
            value={fields.name}
            onChange={handleChange}
            required
            placeholder="Your full name"
            className="temple-input"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1" style={{ color: '#5C3D11', fontFamily: 'Georgia, serif' }}>
            Email Address *
          </label>
          <input
            type="email"
            name="email"
            value={fields.email}
            onChange={handleChange}
            required
            placeholder="your@email.com"
            className="temple-input"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm font-semibold mb-1" style={{ color: '#5C3D11', fontFamily: 'Georgia, serif' }}>
            Phone Number
          </label>
          <input
            type="tel"
            name="phone"
            value={fields.phone}
            onChange={handleChange}
            placeholder="+91 XXXXX XXXXX"
            className="temple-input"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1" style={{ color: '#5C3D11', fontFamily: 'Georgia, serif' }}>
            Subject *
          </label>
          <select
            name="subject"
            value={fields.subject}
            onChange={handleChange}
            required
            className="temple-input"
          >
            <option value="">Select a subject</option>
            <option value="General Enquiry">General Enquiry</option>
            <option value="Donation / 80G">Donation / 80G Enquiry</option>
            <option value="Puja Booking">Puja / Ceremony Booking</option>
            <option value="Event">Upcoming Events</option>
            <option value="Feedback">Feedback / Suggestions</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold mb-1" style={{ color: '#5C3D11', fontFamily: 'Georgia, serif' }}>
          Message *
        </label>
        <textarea
          name="message"
          value={fields.message}
          onChange={handleChange}
          required
          rows={5}
          placeholder="Write your message here..."
          className="temple-input resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 px-6 rounded font-bold text-base transition-all hover:opacity-90 disabled:opacity-60"
        style={{
          background: 'linear-gradient(135deg, #8B0000, #D4A017)',
          color: '#fff',
          fontFamily: 'Georgia, serif',
          cursor: loading ? 'not-allowed' : 'pointer',
        }}
      >
        {loading ? '🙏 Sending...' : '🙏 Send Message'}
      </button>
    </form>
  )
}

function ContactPage() {
  return (
    <div>
      {/* Header */}
      <section
        className="py-20 px-6 text-center"
        style={{
          background: 'linear-gradient(160deg, #8B0000 0%, #4A0E00 50%, #2D1B00 100%)',
          borderBottom: '3px solid #D4A017',
        }}
      >
        <div className="text-4xl mb-3" style={{ color: '#D4A017' }}>🙏</div>
        <h1 className="text-4xl md:text-5xl font-bold mb-3" style={{ color: '#FFFFFF', fontFamily: 'Georgia, serif' }}>
          Contact & Address
        </h1>
        <p className="text-lg" style={{ color: '#C4A882', fontFamily: 'Georgia, serif' }}>
          We welcome all devotees — come, seek blessings
        </p>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">

            {/* Contact Info & Address */}
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
                Visit the Temple
              </h2>

              {/* Address Card */}
              <div
                className="p-8 rounded-2xl mb-6"
                style={{ background: 'linear-gradient(135deg, #8B0000, #4A0E00)', border: '2px solid #D4A017' }}
              >
                <div className="text-3xl mb-4">📍</div>
                <h3 className="font-bold text-xl mb-3" style={{ color: '#F0C040', fontFamily: 'Georgia, serif' }}>
                  Temple Address
                </h3>
                <address className="not-italic text-base leading-relaxed" style={{ color: '#E8D5B0' }}>
                  Beteswar Shiva Mandir<br />
                  [Street / Locality Name]<br />
                  [City / Town], [District]<br />
                  [State] — [PIN Code]<br />
                  India
                </address>
              </div>

              {/* Contact Details */}
              <div className="space-y-4">
                {[
                  { icon: '📞', label: 'Phone', value: '+91 XXXXX XXXXX', href: 'tel:+91XXXXXXXXXX' },
                  { icon: '📧', label: 'Email', value: 'beteswarshivamandir@gmail.com', href: 'mailto:beteswarshivamandir@gmail.com' },
                  { icon: '🌐', label: 'Website', value: 'beteswarshivamandir.netlify.app', href: '#' },
                ].map((contact) => (
                  <a
                    key={contact.label}
                    href={contact.href}
                    className="flex items-center gap-4 p-4 rounded-xl no-underline transition-all hover:opacity-80"
                    style={{ background: '#fff', border: '1px solid #E8D5B0', boxShadow: '0 2px 10px rgba(139,0,0,0.06)' }}
                  >
                    <span className="text-2xl">{contact.icon}</span>
                    <div>
                      <div className="text-xs font-semibold mb-0.5" style={{ color: '#8B0000' }}>{contact.label}</div>
                      <div className="text-sm" style={{ color: '#5C3D11' }}>{contact.value}</div>
                    </div>
                  </a>
                ))}
              </div>

              {/* Temple Hours */}
              <div
                className="mt-6 p-6 rounded-2xl"
                style={{ background: '#F5E6D3', border: '1px solid #E8D5B0' }}
              >
                <h3 className="font-bold text-lg mb-4" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
                  🕐 Temple Hours
                </h3>
                <div className="space-y-3 text-sm">
                  {[
                    { time: 'Morning Darshan', hours: '5:00 AM – 12:00 PM' },
                    { time: 'Afternoon Break', hours: '12:00 PM – 4:00 PM' },
                    { time: 'Evening Darshan', hours: '4:00 PM – 9:00 PM' },
                    { time: 'Special Puja', hours: 'By Prior Appointment' },
                  ].map((h) => (
                    <div key={h.time} className="flex justify-between items-center">
                      <span style={{ color: '#5C3D11' }}>{h.time}</span>
                      <span className="font-semibold" style={{ color: '#8B0000' }}>{h.hours}</span>
                    </div>
                  ))}
                </div>
                <div
                  className="mt-4 pt-4 text-xs"
                  style={{ borderTop: '1px solid #D4A017', color: '#9A7A5A' }}
                >
                  * Temple is open all 365 days including holidays and festivals.
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
                Send a Message
              </h2>
              <div
                className="p-8 rounded-2xl"
                style={{ background: '#fff', border: '2px solid #E8D5B0', boxShadow: '0 8px 30px rgba(139,0,0,0.1)' }}
              >
                <ContactForm />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="pb-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-bold mb-6" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
            📍 Find Us on the Map
          </h2>
          <div
            className="w-full rounded-2xl flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #F5E6D3, #E8D5B0)',
              height: 300,
              border: '2px solid #D4A017',
            }}
          >
            <div className="text-center">
              <div className="text-5xl mb-3">🗺️</div>
              <p className="text-base font-semibold" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
                Beteswar Shiva Mandir
              </p>
              <p className="text-sm mt-1" style={{ color: '#5C3D11' }}>
                Interactive map — embed Google Maps with your address
              </p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mt-4 px-5 py-2 rounded text-sm font-semibold no-underline"
                style={{ background: '#8B0000', color: '#F0C040', fontFamily: 'Georgia, serif' }}
              >
                Open in Google Maps →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Social Links */}
      <section className="py-12 px-6" style={{ background: '#F5E6D3' }}>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-6" style={{ color: '#8B0000', fontFamily: 'Georgia, serif' }}>
            Connect With Us
          </h2>
          <div className="flex justify-center gap-6 flex-wrap">
            {[
              { icon: '📘', name: 'Facebook', color: '#1877F2' },
              { icon: '📸', name: 'Instagram', color: '#E1306C' },
              { icon: '🎬', name: 'YouTube', color: '#FF0000' },
              { icon: '🐦', name: 'Twitter/X', color: '#1DA1F2' },
            ].map((social) => (
              <a
                key={social.name}
                href="#"
                className="flex items-center gap-3 px-6 py-3 rounded-xl no-underline font-semibold text-sm transition-all hover:opacity-80"
                style={{ background: '#fff', border: '1px solid #E8D5B0', color: '#5C3D11' }}
              >
                <span className="text-xl">{social.icon}</span>
                {social.name}
              </a>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
